## This code is abstract and will not run as is: 
## you must code your own mod1.py, mod2.py, mod3.py


# File collector.py
from mod1 import *                               # Collect lots of names here
from mod2 import *                               # from assigns to my names
from mod3 import *


>>> from collector import somename