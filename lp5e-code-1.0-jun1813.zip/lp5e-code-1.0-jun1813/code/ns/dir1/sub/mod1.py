from . import mod2                        # And "from . import string" still fails
print(r'dir1\sub\mod1')

