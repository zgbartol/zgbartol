message = "First version"
def printer():
    print(message)
