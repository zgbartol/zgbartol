X = 99
def printer(): print(X)
