#!/usr/bin/python3
print('Run', 'away!...')          # 3.X function