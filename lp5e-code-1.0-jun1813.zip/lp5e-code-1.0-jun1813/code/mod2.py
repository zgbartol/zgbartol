X = 2
import mod3

print(X, end=' ')             # My global X
print(mod3.X)                 # mod3's X
